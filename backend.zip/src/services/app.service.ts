import { HttpException, HttpStatus } from '@nestjs/common';
import { Injectable } from '@nestjs/common/decorators';
import axios from 'axios';
import { StopWatch } from '../utils/StopWatch';


@Injectable()
export class AppService {
  async getCompanyStatus(company: string) {
    let url: string | string[];

    if (company == 'google-status') {
      url = 'https://google.com';
    } else if (company == 'amazon-status') {
      url = 'https://amazon.com';
    } else if (company == 'all-status') {
      url = ['https://google.com', 'https://amazon.com'];
    }


    if (!url) {
      throw new HttpException('Company Not found', HttpStatus.NOT_FOUND)
    }
    const stopWatch = new StopWatch();
    if (Array.isArray(url)) {
      return await new Promise((resolve, reject) => {
        Promise.all((url as string[]).map((u: string) => axios.get(u))).then(responses => {
          resolve(responses.map((response: any, index: number) => {
            return {
              url: (url as string)[index],
              "statusCode": response.status,
              "duration": stopWatch.elapsedMilliseconds(),
              "date": new Date().valueOf()
            }
          }))
        }).catch(err => {
          console.error(err);
        })
      })
    } else {
      return await new Promise((resolve, reject) => {
        axios.get(url as string).then(res => {
          resolve({
            "url": url,
            "statusCode": res.status,
            "duration": stopWatch.elapsedMilliseconds(),
            "date": new Date().valueOf()
          })
        }).catch(err => {
          reject({
            "url": url,
            "statusCode": err.status,
            "duration": stopWatch.elapsedMilliseconds(),
            "date": new Date().valueOf(),
            "message": err.message
          })
        })
      })
    }
  }
}




