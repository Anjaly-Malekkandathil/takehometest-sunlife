import { Controller, Get, HttpException, HttpStatus, Param } from '@nestjs/common';
import { AppService } from '../services';

@Controller('v1')
export class AppController {
  constructor(private readonly appService: AppService) { }

  @Get(":company")
  async getStatus(@Param() param): Promise<any> {
    return await this.appService.getCompanyStatus(param.company).catch(err => {
      throw new HttpException({
        status: HttpStatus.FORBIDDEN,
        error: err.message,
      }, HttpStatus.FORBIDDEN, {
        cause: err.message
      });
    });
  }

}
