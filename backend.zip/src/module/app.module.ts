import { Module, NestModule, MiddlewareConsumer } from '@nestjs/common';
import { AppController } from '../controllers';
import { AppService } from '../services';


@Module({
  imports: [
  ],
  controllers: [AppController],
  providers: [AppService]
})
export class AppModule implements NestModule {

  configure(consumer: MiddlewareConsumer) {
    //place to inject middleware
  }
}
