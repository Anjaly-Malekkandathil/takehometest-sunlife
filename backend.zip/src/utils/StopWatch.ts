export class StopWatch {
    value = new Date().valueOf();
    elapsedMilliseconds(): number {
        return new Date().valueOf() - this.value;
    }
    elapsedSeconds(): number {
        return (new Date().valueOf() - this.value) / 1000;
    }
    reset(): void {
        this.value = new Date().valueOf();
    }
}