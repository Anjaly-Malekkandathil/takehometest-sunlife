import React, { useEffect, useState } from 'react';
import logo from './logo.svg';
import './App.css';
import axios from 'axios';

const API_URL = 'http://localhost:3010/v1';

interface UrlStatus {
  url: string,
  statusCode: string,
  duration: number,
  date: Date | string
}

function App() {

  const [isLoading, setLoading] = useState<boolean>(true);
  const [isApiLoading, setApiLoading] = useState<boolean>(true);
  const [data, setData] = useState<UrlStatus[]>([]);

  const getData = () => {
    const urls = [`${API_URL}/google-status`,
    `${API_URL}/amazon-status`
    ];
    Promise.all(urls.map((x: string) => axios.get(x))).then(responses => {
      const _serverData: UrlStatus[] = [];
      responses && responses.map(response => {
        _serverData.push(response.data)
      });
      setData(_serverData);
      setLoading(false);
      setApiLoading(false);
    }).catch(err => {
      console.error(err);
    })
  }

  useEffect(() => {
    getData();
    const interval = setInterval(() => {
      setApiLoading(true);
      getData()
    }, 30 * 1000
    )

    return () => clearInterval(interval)
  }, [])


  return (
    <div className="App">
      <header className="App-header">
        <h2>Company Status</h2>

      </header>
      <body>
        {isLoading ? <>Loading...</>
          :
          <div className='table-data'>
            <table>
              <thead>
                <th>URL</th>
                <th>Status</th>
                <th>Duration</th>
                <th>Date</th>
              </thead>
              <tbody>
                {data && data.length > 0 && data.map(_data => {
                  return (
                    <tr>
                      <td>{_data.url}</td>
                      <td>{_data.statusCode}</td>
                      <td>{_data.duration}</td>
                      <td>{_data.date.toString()}</td>
                    </tr>
                  )
                })}
              </tbody>
            </table>
            {isApiLoading && <>Fetching data.....</>}
          </div>
        }

      </body>
    </div>
  );
}

export default App;
